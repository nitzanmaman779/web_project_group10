document.addEventListener('DOMContentLoaded', () => {
    
    // זיהוי המשתמש והגדרת המפתח לשליפה
    const currentUser = localStorage.getItem('currentUser') || 'guest';
    const storageKey = `cellar_${currentUser}`;
    
    // התאמת הכותרת לשם המשתמש (לוקח את החלק שלפני ה-@ באימייל)
    const titleEl = document.getElementById('cellar-title');
    if (currentUser !== 'guest') {
        const namePart = currentUser.split('@')[0];
        // הופך את האות הראשונה לגדולה
        const capitalizedName = namePart.charAt(0).toUpperCase() + namePart.slice(1);
        titleEl.textContent = `${capitalizedName}'s Cellar`;
    }

    const gridEl = document.getElementById('cellar-grid');
    const emptyStateEl = document.getElementById('empty-state');

    // פונקציה לציור המרתף
    const renderCellar = () => {
        // שולפים את המרתף המעודכן מהזיכרון
        let myCellar = JSON.parse(localStorage.getItem(storageKey)) || [];

        // מנקים את ה-HTML הקיים בגריד
        gridEl.innerHTML = '';

        // בודקים אם המרתף ריק
        if (myCellar.length === 0) {
            gridEl.style.display = 'none';
            emptyStateEl.style.display = 'block';
            return;
        }

        // אם יש יינות, מסתירים את המצב הריק ומציגים את הגריד
        emptyStateEl.style.display = 'none';
        gridEl.style.display = 'grid';

        // עוברים על כל יין במערך ומייצרים לו כרטיסייה
        myCellar.forEach(wine => {
            // יצירת אלמנט הכרטיסייה
            const card = document.createElement('div');
            card.classList.add('mini-wine-card');
            
            // תוכן הכרטיסייה 
            card.innerHTML = `
                <button class="btn-remove" data-id="${wine.id}" title="Remove from cellar">🗑️</button>
                <img src="${wine.image}" alt="${wine.name}" class="mini-wine-img">
                <div class="mini-wine-info">
                    <h3 class="mini-wine-name">${wine.name}</h3>
                    <p class="mini-wine-winery">${wine.winery} | ${wine.year}</p>
                </div>
            `;

            // הוספת הכרטיסייה לגריד בעמוד
            gridEl.appendChild(card);
        });

        // הוספת מאזיני אירועים לכפתורי המחיקה 
        attachRemoveListeners();
    };

    // פונקציה לטיפול במחיקת יין
    const removeWine = (wineId) => {
        let myCellar = JSON.parse(localStorage.getItem(storageKey)) || [];
        
        // מסננים החוצה את היין שה-ID שלו תואם לזה שנלחץ
        myCellar = myCellar.filter(wine => wine.id !== wineId);
        
        // שומרים את המערך המעודכן חזרה ל-localStorage
        localStorage.setItem(storageKey, JSON.stringify(myCellar));
        
        // מציירים מחדש את המרתף
        renderCellar();
    };

    // פונקציה לחיבור אירועי הלחיצה לכפתורי הפח
    const attachRemoveListeners = () => {
        const removeButtons = document.querySelectorAll('.btn-remove');
        removeButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                // שולפים את ה-ID ששמרנו בתוך ה-data-id של הכפתור
                const wineId = e.target.getAttribute('data-id');
                removeWine(wineId);
            });
        });
    };

    // ציור ראשוני של המרתף כשהעמוד נטען
    renderCellar();
});