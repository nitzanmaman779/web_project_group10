document.addEventListener('DOMContentLoaded', () => {
    const emailForm = document.getElementById('hero-email-form');
    const emailInput = document.getElementById('hero-email');
    const feedback = document.getElementById('email-feedback');

    if (emailForm) {
        emailForm.addEventListener('submit', (e) => {
            e.preventDefault(); // מונע שליחה אוטומטית של הטופס

            const emailValue = emailInput.value;
            
            // בדיקת ולידציה פשוטה לאימייל
            if (validateEmail(emailValue)) {
                feedback.classList.add('d-none');
                // העברה לדף ההרשמה עם האימייל כפרמטר
                window.location.href = `login.html?email=${encodeURIComponent(emailValue)}`;
            } else {
                feedback.classList.remove('d-none');
                emailInput.classList.add('is-invalid');
            }
        });
    }

    // פונקציית עזר לבדיקת פורמט אימייל
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    // ניקוי השגיאה בזמן שהמשתמש מקליד מחדש
    emailInput.addEventListener('input', () => {
        emailInput.classList.remove('is-invalid');
        feedback.classList.add('d-none');
    });
});



