console.log("Wineder Script Loaded");

// --- פונקציות גולבליות שנגישות מכל מקום באתר ---
// --- התנתקות מוחק מהזיכרון של הדפדפן את העובדה שהמשתמש מחובר, ומעביר אותו חזרה לדף הבית--
window.logout = function() {
    localStorage.removeItem('firstName');
    window.location.href = 'home.html'; 
};
// פונקציה כללית להצגת חלון קופץ (מודאל) להודעות הצלחה 
window.showSuccessModal = function(title, message) {
    const modal = document.getElementById('successModal');
    const titleLabel = document.getElementById('successTitle');
    const msgLabel = document.getElementById('successMessage');
    
    if (modal) {
        if (titleLabel) titleLabel.innerText = title;
        if (msgLabel) msgLabel.innerText = message;
        modal.style.display = 'flex';
    }
};

// מעביר לזירת ההחלקות
    window.redirectToHome = function() {
    window.location.href = 'arena.html'; 
};
// העלמת מסך ההתחברות מהמסך
window.closeModal = function() {
    const modal = document.getElementById('loginModal');
    if (modal) modal.style.display = 'none';
};

//בודק אם המשתמש מחובר לפני שהוא נכנס לדפים פנימיים
// אם הוא לא מחובר - מקפיץ לו חלון התחברות במקום לתת לו להיכנס.
window.checkAccess = function(event, page) {
    event.preventDefault();
    if (!localStorage.getItem('firstName')) {
        const modal = document.getElementById('loginModal');
        if (modal) modal.style.display = 'flex';
    } else {
        window.location.href = page;
    }
};

// ---  לוגיקה אחרי טעינת העמוד ---

document.addEventListener('DOMContentLoaded', () => {
    // מעדכן את התפריט העליון אם המשתמש מחובר הוא מציג את השם שלו וכפתור ניתוק.
    // אם המשתמש לא מחובר, הוא מציג כפתור התחברות.
    const updateHeader = () => {
        const userArea = document.getElementById('userArea');
        if (!userArea) return;
        const firstName = localStorage.getItem('firstName');

        if (firstName) {
            userArea.innerHTML = `
                <span class="me-3 fw-bold" style="color: #B76E79;">Hello, ${firstName}!</span>
                <button class="btn btn-sm btn-outline-secondary" onclick="logout()" style="border-radius: 20px;">
                    Logout <i class="fas fa-sign-out-alt"></i>
                </button>`;
        } else {
            userArea.innerHTML = `<a class="btn btn-outline-gold" href="login.html" style="color: #C68E58; border: 1px solid #C68E58; border-radius: 20px; padding: 5px 15px; text-decoration: none;">Login</a>`;
        }
    };
    // שימוש בזיכרון המקומי של הדפדפן בתור תחליף למסד נתונים 
    const getUsers = () => JSON.parse(localStorage.getItem('winederUsers')) || [];
    const saveUser = (user) => {
        const users = getUsers();
        users.push(user);
        localStorage.setItem('winederUsers', JSON.stringify(users));
    };

    const tabLogin = document.getElementById('tab-login');
    const tabSignup = document.getElementById('tab-signup');
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');

    // טיפול במעבר בין לשונית הרשמה ללשונית התחברות בלי לרענן את הדף
    if (tabLogin && tabSignup) {
        tabLogin.addEventListener('click', () => {
            tabLogin.classList.add('active'); tabSignup.classList.remove('active');
            loginForm.classList.add('active'); signupForm.classList.remove('active');
        });
        tabSignup.addEventListener('click', () => {
            tabSignup.classList.add('active'); tabLogin.classList.remove('active');
            signupForm.classList.add('active'); loginForm.classList.remove('active');
        });
    }

    // טיפול בטופס הרשמה
    if (signupForm) {
        signupForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const firstName = document.getElementById('first-name').value.trim();
            const lastName = document.getElementById('last-name').value.trim();
            const email = document.getElementById('signup-email').value.trim();
            const password = document.getElementById('signup-password').value;
            const ageCheck = document.getElementById('age-check').checked;

            // מוודא שהמשתמש מילא את כל השדות ואישר שהוא מעל גיל 18
            if (!firstName || !lastName || !email || !password || !ageCheck) {
                alert("Please fill all fields and confirm your age (18+).");
                return;
            }

            // בדיקה מול "מסד הנתונים" כדי לוודא שאין כבר משתמש עם אותו אימייל)
            const users = getUsers();
            if (users.find(u => u.email === email)) {
                alert("Email already exists.");
                return;
            }

            // שומר את המשתמש החדש במערכת
            saveUser({ firstName, lastName, email, password });
            
            // מציג הודעת הצלחה למשתמש, מאפס את הטופס ומעביר אותו אוטומטית ללשונית ההתחברות
            window.showSuccessModal("Cheers! Account Created", "Welcome to the Wineder family. You can now login to find your perfect vintage.");
            signupForm.reset();
            
            if (tabLogin) tabLogin.click();
        });
    }

    // טיפול בטופס התחברות 
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const emailInput = document.getElementById('login-email').value.trim();
            const passwordInput = document.getElementById('login-password').value;

            // מחפש במאגר המשתמשים שלנו אם יש מישהו עם אימייל וסיסמה בדיוק כמו שהוזנו בטופס
            const users = getUsers();
            const foundUser = users.find(u => u.email === emailInput && u.password === passwordInput);

            if (foundUser) {
                // אם נמצאה התאמה שומר את שם המשתמש בזיכרון הדפדפן (כדי שישאר מחובר) ומציג הודעת הצלחה
                localStorage.setItem('firstName', foundUser.firstName);
                // מפעיל את מודאל ההצלחה ללוגין
                window.showSuccessModal(`Welcome back, ${foundUser.firstName}!`, "Discover your next favorite vintage with a single swipe.");
            } else {
                // אם אין התאמה מקפיץ הודעת שגיאה
                alert("Invalid email or password.");
            }
        });
    }

    updateHeader();
});